import Keyboard
import Mouse
from tkinter import *
# from tkinter.ttk import *
from PIL import ImageTk, Image


def keyboard():
    Keyboard.main()


def mouse():
    Mouse.main()


root = Tk()
wi, he = 350, 180
# root.geometry(f"{wi}x{he}")
root.geometry("370x240")
# root.maxsize(w, h)
# root.minsize(w, h)
f = Frame(root, borderwidth=20).place(x=60, y=0)
l1 = Label(f, text="Select a device:", font=("Calibri", 15)).place(x=120, y=10)
frame = Frame(root, borderwidth=20)
frame.pack(side=BOTTOM, anchor="nw")
p1 = Image.open("mouse2.png")
img1 = p1.resize((150, 150))
photo1 = ImageTk.PhotoImage(img1)
b1 = Button(frame, image=photo1, command=mouse, bg="white", borderwidth=5).pack(side=LEFT)

p2 = Image.open("keyboard2.jpg")
img2 = p2.resize((150, 150))
photo2 = ImageTk.PhotoImage(img2)
b2 = Button(frame, image=photo2, command=keyboard, bg="white", borderwidth=5).pack(side=LEFT)

root.resizable(False, False)
root.mainloop()
